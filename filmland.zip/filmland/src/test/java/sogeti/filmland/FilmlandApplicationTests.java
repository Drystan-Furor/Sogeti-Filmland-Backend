package sogeti.filmland;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FilmlandApplicationTests {

	@Test
	void contextLoads() {
	}

}
